package com.example.voice_monitor
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity() {}