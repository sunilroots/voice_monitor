
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:noise_meter/noise_meter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vibration/vibration.dart';

void main() {
  runApp(const VoiceMonitorApp());
}

class VoiceMonitorApp extends StatelessWidget {
  const VoiceMonitorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Voice Monitor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const MonitorScreen(),
    );
  }
}

class MonitorScreen extends StatefulWidget {
  const MonitorScreen({super.key});
  @override
  State<MonitorScreen> createState() => _MonitorScreenState();
}

class _MonitorScreenState extends State<MonitorScreen> {
  final NoiseMeter _noiseMeter = NoiseMeter();
  StreamSubscription<NoiseReading>? _sub;

  double loudThreshold = 75;
  int fastThreshold = 18;

  double currentDb = 0;
  int segments = 0;
  bool wasSpeaking = false;
  String status = 'Idle';
  bool listening = false;

  Timer? resetTimer;

  @override
  void dispose() {
    _sub?.cancel();
    resetTimer?.cancel();
    super.dispose();
  }

  Future<void> start() async {
    if (!await Permission.microphone.request().isGranted) {
      setState(() => status = 'Mic permission denied');
      return;
    }

    resetTimer = Timer.periodic(Duration(seconds: 10), (_) {
      setState(() => segments = 0);
    });

    _sub = _noiseMeter.noiseStream.listen((event) {
      double db = event.meanDecibel.isFinite ? event.meanDecibel : 0.0;
      bool speaking = db > 55;

      if (speaking && !wasSpeaking) segments++;
      wasSpeaking = speaking;

      String newStatus = 'Calm';
      if (db >= loudThreshold) newStatus = 'LOUD';
      else if (segments >= fastThreshold) newStatus = 'FAST';

      setState(() {
        currentDb = db;
        status = newStatus;
      });

      if (newStatus != 'Calm') {
        Vibration.vibrate(duration: 200);
      }
    });

    setState(() {
      listening = true;
      status = 'Listening';
    });
  }

  void stop() {
    _sub?.cancel();
    resetTimer?.cancel();
    setState(() {
      listening = false;
      status = 'Stopped';
      currentDb = 0;
      segments = 0;
      wasSpeaking = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    double meter = ((currentDb - 40) / 50).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(title: Text('🎤 Voice Monitor')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text(status, style: TextStyle(fontSize: 20)),
            SizedBox(height: 12),
            LinearProgressIndicator(value: meter),
            SizedBox(height: 12),
            Text('${currentDb.toStringAsFixed(1)} dB'),
            SizedBox(height: 12),
            Text('Speech bursts: $segments'),

            Spacer(),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: listening ? null : start,
                    child: Text("Start"),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: listening ? stop : null,
                    child: Text("Stop"),
                  ),
                ),
              ],
            ),

            SizedBox(height: 12),
            Text(
              "Foreground only — stops when app is minimised or screen is off.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.white70),
            )
          ],
        ),
      ),
    );
  }
}
